#'Building a Model for Staff Optimization in a retail store.
#'Reading the dataset.
#'This function read the data

read_data<-function(d){
  x<-read.csv(d)
  return(x)
}

#'Building a Model for Staff Optimization in a retail store.
#'
#'@param dataset column_name(skillset column name eg:clothing obs:4 r 5) a(Total Volumns of stock,eg:330) i-skillset range(vector of length,eg:4,3) j(Emp_id column) k(Number of units handled by each person,eg:19)
#'
#'@return A dataframe with the Employee ids and their skillsets in their department.
#'
#'@author Sujith Kumar
#'@details
#'This function subsets the data based on their skillsets.
#'It makes two subsets of data,
#'firt subset is that the employees with the highest skill value in their respective department.
#'second subset is that the employees with the next best skill value after the first subset and also store in descreasing order of skill values .It will treat as available employees
#'It will calculate required employees based on(volume of stock/how much volumn of stock that each person can handle)
#'Then it will check the condition whether the persons required or not if it require whom to swap.
#'

SO<-function(MyData,data1,a,i,j,k){

  ##data with 4&5 scores in skillset

  newdata_clothing <- subset(MyData, MyData[,which(colnames(MyData)==data1)]>= i[1] ,select= c(j,data1))

  ##data with 3 and below scores in skillset

  newdata1_clothing <- subset(MyData, MyData[,which(colnames(MyData)==data1)] <= i[2] ,select= c(j,data1))

  ## sorting in descending order


  newdata1_clothing[,which(colnames(newdata1_clothing)==data1)]=sort(newdata1_clothing[,which(colnames(newdata1_clothing)==data1)],decreasing = TRUE)

  ##employees available per department

  Available_emp_clothing=length(newdata_clothing[,which(colnames(newdata_clothing)==j)])

  ##employees required per department

  emp_required_clothing=a/k

  ##additional employees required per department

  difference_emp_clothing=emp_required_clothing-Available_emp_clothing

  ##additional rows that has to be added to available employees to meet requirment

  additional_clothing=newdata1_clothing[1:(difference_emp_clothing),]


  if(emp_required_clothing > Available_emp_clothing){
    newlist_clothing=rbind(newdata_clothing,additional_clothing)
  }else{
    newlist_clothing=newdata_clothing[1:(nrow(newdata_clothing)-length(difference_emp_clothing)),]
  }

  return(newlist_clothing)

}
